TMI_TOKEN = 'oauth:'
CLIENT_ID= ''
BOT_NICK= ''
BOT_PREFIX= '!'
CHANNEL='#'

# Тут рассказано как получить реквизиты
# https://www.youtube.com/watch?v=w8HRE-NNfnk