test_token_v2 = ''
account_id_test = ''

# Тут рассказано как получить токен
# https://tinkoff.github.io/investAPI/token/

# Получить account_id
# client.operations.get_positions(account_id=tinkoff_creds.account_id_test)